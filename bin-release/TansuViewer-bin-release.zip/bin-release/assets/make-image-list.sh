ls images | grep '.jpg' > image-list.txt
